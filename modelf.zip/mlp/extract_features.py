# task_1/extract_features.py
import numpy as np
import cv2
import os
from pathlib import Path
from feature_extractor import extract_handcrafted_features 

def process_dataset(data_dir, save_prefix):
    """
    遍历 data_dir 下所有图像（支持带子文件夹 or 平铺）
    提取特征并保存为 .npy 文件
    """
    data_path = Path(data_dir)
    features = []
    labels = []
    filenames = []

    if (data_path / "test").exists() and "test" in str(data_path):
        # 测试集：平铺结构
        image_files = sorted([f for f in data_path.iterdir() if f.suffix.lower() in ('.jpg', '.png', '.jpeg')])
        for img_path in image_files:
            feat = extract_handcrafted_features(img_path)
            features.append(feat)
            filenames.append(img_path.name)
        # 保存
        np.save(f"{save_prefix}_features.npy", np.array(features))
        np.save(f"{save_prefix}_filenames.npy", np.array(filenames))
        print(f"✅ 测试集特征已保存: {save_prefix}_features.npy ({len(features)} 张)")
    else:
        # 训练/验证集：按类别子文件夹
        class_to_idx = {}
        for idx, class_dir in enumerate(sorted(data_path.iterdir())):
            if not class_dir.is_dir():
                continue
            class_name = class_dir.name
            class_to_idx[class_name] = idx
            for img_path in class_dir.iterdir():
                if img_path.suffix.lower() in ('.jpg', '.png', '.jpeg'):
                    feat = extract_handcrafted_features(img_path)
                    features.append(feat)
                    labels.append(idx)
                    filenames.append(img_path.name)
        # 保存
        np.save(f"{save_prefix}_features.npy", np.array(features))
        np.save(f"{save_prefix}_labels.npy", np.array(labels))
        np.save(f"{save_prefix}_filenames.npy", np.array(filenames))
        # 保存类别映射
        import json
        with open(f"{save_prefix}_class_to_idx.json", "w") as f:
            json.dump({k: v for k, v in class_to_idx.items()}, f)
        print(f"✅ 训练集特征已保存: {len(features)} 张, {len(class_to_idx)} 类")

if __name__ == "__main__":
    # 提取训练集特征
    process_dataset("data/train", "train")
    # 提取测试集特征（平铺）
    process_dataset("data/test", "test")