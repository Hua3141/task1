# task_1/model/model.py

import torch
import torch.nn as nn
from pathlib import Path

# ========== 新增：纯 MLP 模型 ==========
class MLPClassifier(nn.Module):
    def __init__(self, num_classes: int, input_size: int = 224, hidden_layers: list = None):
        """
        纯全连接神经网络图像分类器（不使用 CNN）
        
        Args:
            num_classes (int): 分类类别数
            input_size (int): 输入图像边长（假设为正方形，如 224）
            hidden_layers (list): 隐藏层神经元数量，例如 [512, 256, 128]
        """
        super(MLPClassifier, self).__init__()
        self.input_features = input_size * input_size * 3  # RGB 图像
        
        if hidden_layers is None:
            hidden_layers = [512, 256, 128]  # 默认三层
        
        layers = []
        in_features = self.input_features
        
        for h in hidden_layers:
            layers.append(nn.Linear(in_features, h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.5))  # 强正则化，防过拟合
            in_features = h
        
        layers.append(nn.Linear(in_features, num_classes))
        self.mlp = nn.Sequential(*layers)
    
    def forward(self, x):
        # x: [B, 3, H, W]
        x = x.view(x.size(0), -1)  # 展平为 [B, 3*H*W]
        return self.mlp(x)

    def save(self, save_path: str):
        torch.save(self.state_dict(), save_path)
        print(f"MLP 模型已保存至: {save_path}")

    def load(self, load_path: str, map_location=None):
        self.load_state_dict(torch.load(load_path, map_location=map_location))
        print(f"MLP 模型已从 {load_path} 加载")

    @staticmethod
    def get_device():
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")