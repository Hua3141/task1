# task_1/model/feature_extractor.py
import cv2
import numpy as np

def extract_handcrafted_features(image_path):
    img = cv2.imread(str(image_path))
    if img is None:
        raise ValueError(f"无法读取图像: {image_path}")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    features = []

    # 1. 颜色均值和标准差 (6维)
    for ch in cv2.split(img):
        features.extend([ch.mean(), ch.std()])
    
    # 2. RGB 直方图 (24维: 8 bins * 3 channels)
    for ch in cv2.split(img):
        hist = cv2.calcHist([ch], [0], None, [8], [0, 256])
        hist = hist.flatten() / (hist.sum() + 1e-6)  # 防除零
        features.extend(hist)
    
    # 3. 边缘密度 (1维)
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    features.append(edges.mean() / 255.0)
    
    return np.array(features, dtype=np.float32)